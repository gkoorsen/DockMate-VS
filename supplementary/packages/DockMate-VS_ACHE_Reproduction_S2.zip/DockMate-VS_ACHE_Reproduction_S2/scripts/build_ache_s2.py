"""Wrap the frozen ACHE supplement as manuscript S2 without changing evidence."""
from pathlib import Path
import argparse
import csv
import hashlib
import io
import json
import shutil
import subprocess
import sys
import zipfile

NAME = 'DockMate-VS_ACHE_Reproduction_S2'
ORIGINAL_SHA = '0e4ae73feca1137745c335773211f9dabaf8a6e39fe031fd6efdc1292400e9b7'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True, help='Fresh build directory')
    args = p.parse_args()
    if args.output.exists():
        p.error('Output directory must be new.')
    raw = args.source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA:
        raise ValueError('Source is not the verified frozen supplement ZIP.')
    root = args.output / NAME
    root.mkdir(parents=True)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for name in z.namelist():
            relative = Path(name).relative_to('DockMate-VS_ACHE_Reproducibility_Supplement')
            if name.endswith('/'):
                continue
            # Original plots and builders remain in the sealed original archives.
            # Expose only reconciled presentation figures in the new wrapper.
            if relative.parts[0] == 'figures' or str(relative) == 'scripts/build_supplement.py':
                continue
            dest = root / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(name))
    templates = Path(__file__).resolve().parents[1] / 'supplementary/ache'
    for f in templates.iterdir():
        if f.is_file():
            shutil.copy2(f, root / f.name)
    (root / 'scripts').mkdir(exist_ok=True)
    shutil.copy2(__file__, root / 'scripts/build_ache_s2.py')
    diagnostic = root / 'annotation_diagnostics'
    diagnostic.mkdir()
    with zipfile.ZipFile(root / 'evidence/ACHE_single_matched_live_execution.zip') as z:
        for name in ('pose_comparison.csv', 'summary.json'):
            (diagnostic / name).write_bytes(z.read(
                'ACHE_matched_live/diagnostics/final_pose_check_20261026T201436/' + name))
        source = root / 'figure6_source'
        source.mkdir()
        for name in ['per_compound_comparison.csv', 'archived_pr.csv', 'archived_roc.csv',
                     'live_pr.csv', 'live_roc.csv', 'comparison.json', 'score_discrepancies.csv']:
            (source / name).write_bytes(z.read('ACHE_matched_live/analysis/' + name))
    subprocess.run([sys.executable, str(root / 'plot_figure6.py'), '--output', str(root / 'figures')], check=True)
    subprocess.run([sys.executable, str(root / 'render_report.py'), str(root)], check=True)
    audit = subprocess.run([sys.executable, str(root / 'verify_annotations.py')],
                           check=True, text=True, capture_output=True)
    (root / 'ANNOTATION_AUDIT.json').write_text(audit.stdout)
    # The nested archive remains byte-identical. Inventory distinguishes its
    # paths from outer files; inventory/checksum self-references are excluded.
    entries = []
    for f in sorted(root.rglob('*')):
        if f.is_file() and f.name != 'SHA256SUMS.json':
            data = f.read_bytes()
            entries.append(['S2', f.relative_to(root).as_posix(), len(data), hashlib.sha256(data).hexdigest()])
    with zipfile.ZipFile(root / 'evidence/ACHE_single_matched_live_execution.zip') as z:
        for name in sorted(z.namelist()):
            data = z.read(name)
            entries.append(['evidence/ACHE_single_matched_live_execution.zip', name,
                            len(data), hashlib.sha256(data).hexdigest()])
    with (root / 'FILE_INVENTORY.csv').open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Container', 'Path', 'Bytes', 'SHA256'])
        w.writerows(entries)
    hashes = {}
    for f in sorted(root.rglob('*')):
        if f.is_file() and f != root / 'SHA256SUMS.json':
            data = f.read_bytes()
            hashes[f.relative_to(root).as_posix()] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    (root / 'SHA256SUMS.json').write_text(json.dumps(hashes, indent=2) + '\n')
    archive = args.output / (NAME + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in sorted(root.rglob('*')):
            if f.is_file():
                z.write(f, f.relative_to(args.output))
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n')
    print(json.dumps(dict(archive=str(archive), sha256=digest, bytes=archive.stat().st_size,
                          payload_files=len(hashes), inventory_records=len(entries)), indent=2))


if __name__ == '__main__':
    main()
