"""Render current S2 prose without modifying the sealed historical evidence."""
from pathlib import Path
import html
import json
import sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle


def main(root):
    path = root / 'SUPPLEMENT_CONTENT.json'
    content = json.loads(path.read_text())
    def reconcile(value):
        if isinstance(value, dict): return {k: reconcile(v) for k, v in value.items()}
        if isinstance(value, list): return [reconcile(v) for v in value]
        if not isinstance(value, str): return value
        for old, new in [('matched live-execution test', 'matched rerun'),
                         ('archived/live scores', 'archived/rerun scores'),
                         ('For a new live execution', 'For a future rerun'),
                         ('matched-execution', 'matched-rerun')]:
            value = value.replace(old, new)
        return value
    content = reconcile(content)
    content['sections'].append(dict(title='10. Packaging, Figure 6 and discrepancy files', table=None, paragraphs=[
        'Reader-facing descriptions use rerun. Historical paths and schema names, including live/batch_001, live_affinity and live_all_compounds, remain unchanged. Wording inside the sealed historical evidence is preserved as provenance, not as current presentation text.',
        'analysis/score_discrepancies.csv is a filtered table, not the full compound table. The original analysis retains evaluable compounds for which abs(live_affinity - archived_affinity) exceeds 1e-12 kcal/mol. Zero of the 1,240 evaluable records meet that filter, so the file correctly contains its column header and zero data rows. It does not summarize atom-type or partial-charge discrepancies; those are reported separately in annotation_diagnostics/pose_comparison.csv.',
        'plot_figure6.py generates the final two-panel Figure 6: (a) coincident precision-recall curves with the random-ranking prevalence baseline and (b) class-specific affinity markers with area proportional to count. There is no ROC panel. The figure uses all 1,240 compounds, with 101 distinct reported affinities and a largest marker of 35 decoys at -8.3 kcal/mol. figure6_source/ retains the complete compound comparison and full curve data; ROC data remain available for audit, not as a figure panel. python plot_figure6.py --output ../figure6-redraw redraws the figure. python regenerate.py --output ../ache-reanalysis recalculates the data and then generates Table 2 and Figure 6. The original independent analysis and its older three-panel plot remain sealed as historical evidence. The final manuscript PNG and exact supplied caption are included as references; regenerated pixel identity is not claimed.',
        'This S2 package concerns ACHE only; S1 concerns ESR1 only. No Astex submission or benchmark material is included. General implementation files in the executed source snapshot remain part of code provenance. The original evidence archive is unchanged; refreshed reports and figure labels are packaging changes, not a new docking campaign.',
        'FILE_INVENTORY.csv lists payloads with their hashes. Final distribution inventories supplied alongside S1/S2 also include checksum and inventory files, and recursively list nested ZIP members. The README documents verification and reanalysis commands. No manuscript editing or external submission is performed by packaging.'
    ]))
    path.write_text(json.dumps(content, indent=2) + '\n')
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='SupplementBody', fontName='Helvetica', fontSize=9.5, leading=13.5, spaceAfter=7))
    styles.add(ParagraphStyle(name='SupplementTable', fontName='Helvetica', fontSize=8, leading=10.5))
    title = content['title']
    story = [Paragraph(html.escape(title), styles['Title'])]
    body = ['<h1>' + html.escape(title) + '</h1>']
    text = [title, '']
    for section in content['sections']:
        story.append(Paragraph(html.escape(section['title']), styles['Heading2']))
        body.append('<h2>' + html.escape(section['title']) + '</h2>')
        text.extend([section['title'], ''])
        for paragraph in section['paragraphs']:
            story.append(Paragraph(html.escape(paragraph), styles['SupplementBody']))
            body.append('<p>' + html.escape(paragraph) + '</p>')
            text.extend([paragraph, ''])
        if section['table']:
            rows = section['table']
            cells = [[Paragraph(html.escape(c), styles['SupplementTable']) for c in row] for row in rows]
            width = A4[0] - 36 * mm
            widths = [width / len(rows[0])] * len(rows[0])
            if len(widths) == 2: widths = [width * .32, width * .68]
            table = Table(cells, colWidths=widths, repeatRows=1)
            table.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e7f1f1')),
                ('VALIGN', (0,0), (-1,-1), 'TOP'), ('LINEBELOW', (0,0), (-1,-1), .35, colors.lightgrey),
                ('TOPPADDING', (0,0), (-1,-1), 5), ('BOTTOMPADDING', (0,0), (-1,-1), 5)]))
            story.extend([table, Spacer(1, 4*mm)])
            text.extend(' | '.join(row) for row in rows)
            body.append('<table>' + ''.join('<tr>' + ''.join('<td>' + html.escape(c) + '</td>' for c in row) + '</tr>' for row in rows) + '</table>')
    SimpleDocTemplate(str(root / 'REPRODUCIBILITY_SUPPLEMENT.pdf'), pagesize=A4,
                      leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm,
                      title=title).build(story)
    (root / 'REPRODUCIBILITY_SUPPLEMENT.txt').write_text('\n'.join(text) + '\n')
    (root / 'REPRODUCIBILITY_SUPPLEMENT.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>' + html.escape(title) + '</title><style>body{font:16px/1.6 sans-serif;max-width:1080px;margin:40px auto;padding:0 24px;overflow-wrap:anywhere}td{padding:8px;border-bottom:1px solid #ddd}img{width:100%}</style>' + ''.join(body) + '<h2>Figure 6</h2><img src="figures/Figure_6.png" alt="Archived and rerun curves and score agreement"></html>')


if __name__ == '__main__':
    main(Path(sys.argv[1]))
