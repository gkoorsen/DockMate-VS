SUPPLEMENT S2: ACHE MATCHED RERUN

Archive: DockMate-VS_ACHE_Reproduction_S2.zip
Manuscript: SOFTX-D-26-01226, DockMate-VS (SoftwareX)
Intended submission location: accompanying journal supplementary material, S2.
Packaging status: prepared locally for submission; no journal upload or public
deposit is claimed. No public deposit DOI/URL has yet been assigned to S2.
The v0.1.3 software DOI does not identify this later evidence package.
S2 is the author's package identifier, subject to journal assignment.

START HERE
Read REPRODUCIBILITY_SUPPLEMENT.pdf (also HTML/TXT) for methods and limitations.
COMPOUND_TABLE.csv and the Compounds sheet in COMPOUND_TABLE.xlsx each contain
all 1,240 compounds: 40 actives and 1,200 decoys. The CSV has no index column;
a display stopping at zero-based position 999 omits 240 rows from its preview.
FILE_INVENTORY.csv lists outer payloads and every file in the nested evidence
archive, with byte counts and SHA-256 digests. SHA256SUMS.json verifies all
outer payload files except itself. A sibling .zip.sha256 verifies the ZIP.

VERIFY (standard-library Python only)
Before extraction, from the ZIP's directory:
  shasum -a 256 -c DockMate-VS_ACHE_Reproduction_S2.zip.sha256
Extract the ZIP, then change into DockMate-VS_ACHE_Reproduction_S2/ and run:
  python verify_archive.py
  python verify_annotations.py

The second command reads complete CSV and Excel files, verifies 1,240 unique
IDs and identical populations against the input labels, native result table
and diagnostic table, then recalculates annotation comparisons from the sealed
MOL2 files. It requires only Python's standard library. ANNOTATION_AUDIT.json
records the successful build-time audit; running the command repeats it.

ANNOTATION EVIDENCE
annotation_diagnostics/pose_comparison.csv contains all 1,240 compound rows,
including atom_types_match AND charges_match, plus companion archive flags.
annotation_diagnostics/summary.json is the original final diagnostic summary.
These are byte-identical copies from the sealed evidence archive's directory
ACHE_matched_live/diagnostics/final_pose_check_20261026T201436/.
Against the protocol archive: 101 decoys differ in atom types and 172 in partial
charges, with no active discrepancies. These categories can overlap. All 1,240
stored coordinate arrays match. Against the companion archive, coordinates,
atom types and charges all match for all 1,240 compounds.

The original diagnostic code is included in the nested evidence at
ACHE_matched_live/scripts/inspect_saved_poses.py; exact inspected snapshots,
reference MOL2 files, companion poses and companion provenance are also there.
To rerun that original diagnostic after the regeneration command below:
  python ../ache-reanalysis/ACHE_matched_live/scripts/inspect_saved_poses.py
It writes a new timestamped diagnostics/final_pose_check_* directory in that
working copy. It requires NumPy (included in analysis-requirements.txt).
verify_annotations.py additionally provides an independent standard-library
implementation and checks each comparison flag against the original CSV.
Comparisons use saved atom order, without fitting or atom remapping, and count
compounds with differing annotations, not numbers of differing atoms.

REGENERATE MANUSCRIPT TABLE 2 AND FIGURE 6
Use Python 3.11 in a separate environment. From the extracted S2 directory:
  python -m venv ../ache-analysis-env
  source ../ache-analysis-env/bin/activate
  python -m pip install -r analysis-requirements.txt
  python regenerate.py --output ../ache-reanalysis

Use a new output directory; existing directories are rejected. This verifies
S2, extracts a separate working copy and runs the original independent analysis
on native stdout and MOL2 outputs. No docking, preparation or tuning occurs.
It requires exact equality with the frozen comparison.json and checks that
non-analysis evidence remains unchanged. The sealed evidence ZIP is untouched.

Outputs in ../ache-reanalysis/:
  Table_2.csv: all six rows of manuscript Table 2, with six-decimal AUC values.
  Figure_6.png and Figure_6.pdf: final two-panel figure showing (a) coincident
    precision-recall curves with the random-ranking prevalence baseline and
    (b) class-specific, count-sized affinity agreement. There is no ROC panel.
  Figure_6_affinity_counts.csv: full class/value counts used for marker areas.
  Figure_6_verification.json: checks of the panel design and caption numbers.
  Figure_6_caption.txt: suggested manuscript caption and interpretation limits.
  REGENERATION_CHECK.json: numerical agreement and evidence-integrity check.
  ACHE_matched_live/analysis/: full independent metrics, all 1,240 compound
    records, curves, Excel comparison and reanalysis environment information.

FIGURE 6 PLOTTING CODE AND FULL SOURCE DATA
plot_figure6.py draws the final two panels with reader-facing "rerun" labels.
figure6_source/ contains the complete 1,240-row per_compound_comparison.csv,
archived_pr.csv, archived_roc.csv, live_pr.csv, live_roc.csv, comparison.json
and score_discrepancies.csv. These seven files are byte-identical to the sealed
analysis outputs; verify_annotations.py checks this explicitly. The original
independent calculation code is in the sealed scripts/analyse.py. To redraw
only the figure from supplied data, without recalculating statistics:
  python plot_figure6.py --output ../figure6-redraw

ROC curve data remain archived for Table 2 and audit purposes; they are not
plotted in the final Figure 6. The sealed historical analysis still contains
its older three-panel plot; that is not the manuscript Figure 6. The supplied
final manuscript PNG is retained as Figure_6_manuscript_reference.png with
its source hash in FIGURE_6_REFERENCE.json. Regeneration reproduces the final
two-panel design and data; pixel identity across rendering environments is
not claimed. FIGURE_6_CAPTION.txt contains the user-supplied final caption.

HEADER-ONLY SCORE-DISCREPANCY TABLE
figure6_source/score_discrepancies.csv (also analysis/score_discrepancies.csv
in the sealed evidence) contains the CSV header and zero data rows by design.
It selects evaluable compounds with abs(live_affinity - archived_affinity)
greater than 1e-12 kcal/mol. All 1,240 compounds are evaluable and none meets
that filter. The file is neither the full compound table nor the annotation
discrepancy table. Atom-type and charge differences are documented separately
under annotation_diagnostics/; zero score discrepancies does not negate them.

The pinned requirements record the successful original analysis environment;
they are not the historical engine environment. PDF timestamps and rendering
may vary across environments even when the numerical comparison is identical.

EVIDENCE LAYOUT
evidence/ACHE_single_matched_live_execution.zip is the original sealed archive,
unchanged. Its root ACHE_matched_live/ includes:
  protocol_lock.json, execution.yml: fixed protocol and execution settings.
  inputs/: archived prepared receptor, reference ligand and compound libraries.
  software/: executed source snapshot and software/build provenance.
  reference/: archived scores/labels and sealed successful import baseline.
  live/: generated native poses, stdout/stderr, commands and DockMate exports.
  scripts/analyse.py: independent native-output parsing, metrics and plotting.
  analysis/: frozen full comparison, curve data and original figure.
  diagnostics/: annotation comparisons and companion-archive provenance.
  Host-runtime and power-event records document sleep-interrupted wall time.
Use FILE_INVENTORY.csv for exact names; Docker image identity/configuration is
archived, but image layers are not included. Executed source declares 0.1.3
with additional development changes; installed image metadata reports 0.1.0.
Historical executable bit identity is unproven. See the reproducibility report
for the atom annotation differences and runtime interpretation.

PACKAGING SCOPE AND TERMINOLOGY
Current descriptions and Figure 6 use "rerun". Historical names such as
live/batch_001, live_affinity and live_pr.csv remain unchanged. Original prose
and figures inside sealed historical evidence retain their original wording.
Only ESR1 (S1) and ACHE (S2) evidence belongs to this submission set; no Astex
submission files or benchmark results are included. Generic implementation
files inside the frozen executed source tree remain code provenance.
The final sign-off bundle supplies complete recursive S1/S2 inventories,
copies of these READMEs and captured verification outputs. Inventory/checksum
self-references are excluded from the in-package payload inventory, but are
included in those external final inventories.

MANUSCRIPT AVAILABILITY WORDING
After uploading S2 with the revision, use AVAILABILITY_TEXT.txt. Until then,
describe this archive as prepared for submission, not already deposited.
