# Suggested manuscript text

Current availability wording: upload is not yet confirmed. Add the journal
supplement location or a commit-specific repository permalink after publication.
The supplement is separate from the Zenodo software archive.

## Data and code availability

DockMate-VS is available under the MIT License at
https://github.com/gkoorsen/DockMate-VS. Version 0.1.1 is archived at
https://doi.org/10.5281/zenodo.22685196; all versions are accessible through
https://doi.org/10.5281/zenodo.22283781. The reconstruction-based ESR1 supplement has been prepared for submission as journal supplementary material, DockMate-VS_ESR1_Supplement_S1.zip (Supplement S1), with the repository copy at supplementary/packages/DockMate-VS_ESR1_Supplement_S1.zip. It provides the ordered ESR1 subset identifiers, source checksums, campaign settings, structure-free result tables, and scripts for reconstructing screening inputs and reproducing the statistical analyses. The size-controlled analysis of Section 3.2 is included as publication/tables/esr1_mw_controlled.csv with its generating script and a verification command (MW_CONTROLLED.md). LIT-PCBA compound structures are not
redistributed: users obtain the original archive from its provider [6] and
reconstruct the inputs locally. Receptor and reference-ligand structures are
available from the Protein Data Bank under accession 1XP1 [18].

## Case-study version clarification

The ESR1 docking calculations were generated with an earlier development
version using the then-available adaptive ligand-variant selection; the saved
results were subsequently inspected with the version 0.1.1 GUI. Historical
settings and environment information are retained in the ESR1 supplement.

## Property-only diagnostic methods

A property-only logistic regression used molecular weight, logP, topological
polar surface area, rotatable-bond count, and ligand charge recorded during
preparation. Features were standardized within each training fold, and the
classifier was evaluated using 10-fold stratified, shuffled cross-validation
(seed 42). The model used L2 regularization with C=1 and the lbfgs solver; mean
ROC AUC was calculated across the ten held-out folds.
